﻿#include <iostream>
#include "DbSet.h"
#include <fstream>
#include <tuple>


// Why not "using namespace std"?
// Bởi vì em muốn biết được hàm nào có sẵn từ thư viện std và 
// hàm nào là em viết ra.

int main() {
	StudentToStringUIConverter converter;
	const std::string FILENAME = "students.txt";
	std::fstream fin(FILENAME);
	DbSet* database = new DbSet(FILENAME);

	auto res = database->getAll();	// return tuple<b, i, str, vt(student)>
	bool isSuccess = true;
	int error_code = 0;
	std::string message = "";
	std::vector<std::shared_ptr<Student>> items = std::get<3>(res);
	tie(isSuccess, error_code, message, items) = res;

	std::vector<std::shared_ptr<Student>> randomStudent = database->getRandomStudent();
	items = database->concat(randomStudent);

	// over write
	auto check = database->overWrite(randomStudent);
	bool isOverWrite = check.first;
	std::string msg = check.second;
	if (isOverWrite == false) {
		std::cout << msg << std::endl;
	}

	// print all students
	std::cout << "All Students:" << std::endl;
	if (isSuccess == true) {
		for (auto item : items) {
			std::cout << converter.next(item) << std::endl;
		}
	}else {
		std::cout << message <<std::endl;
		std::cout << "Can not display students from data file" << std::endl;
		for (auto item : randomStudent) {
			std::cout << converter.next(item) << std::endl;
		}
	}
	// the list of students that have greater than x GPA
	float gpa = Util::uStudent::Average(items);
	std::cout << "The average GPA is: " << gpa << std::endl;
	std::cout << "The list of students that have greater than " << gpa << " GPA is:" << std::endl;
	auto findedStudent = Util::uStudent::Filter(items, gpa);
	for (auto item : findedStudent) {
		std::cout << converter.next(item) << std::endl;
	}	
	std::cin.get();
}
