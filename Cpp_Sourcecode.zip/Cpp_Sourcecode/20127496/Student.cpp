#include "Student.h"

bool Student::isValidDOB(const std::string& dob) {
	const std::string pattern = "([0-9]{1,2}\\/){2}[0-9]{4}";
	std::regex digitPattern(pattern);

	bool result = regex_match(dob, digitPattern);
	return result;
}

bool Student::isValidID(const std::string& id) {
	const std::string pattern = "\\d+";
	std::regex digitPattern(pattern);

	bool result = regex_match(id, digitPattern);
	return result;
}

bool Student::isValidName(const std::string& name) {
	const std::string pattern = "(([A-Z])\\w+\\s){1,4}(([A-Z])\\w+\\S)";
	std::regex digitPattern(pattern);

	bool result = regex_match(name, digitPattern);
	return result;
}
bool Student::isValidGPA(const std::string& GPA) {
	const std::string pattern = "[0-9]{1,2}(.\\d\\d?)?";
	std::regex digitPattern(pattern);

	bool result = regex_match(GPA, digitPattern);
	return result;
}

bool Student::isValidTelephone(const std::string& telephone) {
	const std::string pattern = "0\\d{3}(-\\d{3}){2}";
	std::regex digitPattern(pattern);

	bool result = regex_match(telephone, digitPattern);
	return result;
}

bool Student::isValidemail(const std::string& email) {
	const std::string pattern = "\\w+@student.hcmus.edu.vn";
	std::regex digitPattern(pattern);

	bool result = regex_match(email, digitPattern);
	return result;
}
