#include <string>
#include <vector>
#include "Util.h"
#include <tuple>
#include <fstream>
#include "RandomGenerator.h"
#include "StudentToStringUIConverter.h"
#include <memory.h>

class DbSet {
private:
	std::string _filename;
	std::vector<std::shared_ptr<Student>> _students;
public:
	DbSet() {
		// do not thing
	}

	DbSet(const std::string &filename) 
		:_filename(filename) {}

	std::tuple<bool, int, std::string, std::vector<std::shared_ptr<Student>>> getAll();
	std::pair<bool, std::string> overWrite(const std::vector <std::shared_ptr<Student>>& Students);
	std::vector<std::shared_ptr<Student>> getRandomStudent();
	std::vector<std::shared_ptr<Student>> concat(const std::vector<std::shared_ptr<Student>>& other);
};
