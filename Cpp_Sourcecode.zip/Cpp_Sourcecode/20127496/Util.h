#include <string>
#include <vector>
#include "Student.h"

namespace Util {
	class uStudent {
	public:
		static float Average(const std::vector<std::shared_ptr<Student>> &items) {
			const int N_ITEMS = items.size();
			float result = 0;
			for (auto item : items) {
				result += stof(item->getGPA());
			}
			result = result / N_ITEMS;
			return result;
		}

		static std::vector<std::shared_ptr<Student>> Filter(const std::vector<std::shared_ptr<Student>> &items,const float &gpa) {
			std::vector<std::shared_ptr<Student>> result;
			for (auto item : items) {
				if (stof(item->getGPA()) > gpa) {
					result.push_back(item);
				}
			}
			return result;
		}
	};
};
