#include <string>
#include <regex>


class Student {
private:
	std::string _id;
	std::string _name;
	std::string _gpa;
	std::string _telephone;
	std::string _email;
	std::string _dob;
	std::string _address;
public:
	Student() {

	}

	Student(std::string id, std::string name, std::string gpa, std::string telephone,
		std::string email, std::string dob, std::string address) 
			:_id(id), _name(name), _gpa(gpa), _telephone(telephone),
			_email(email), _dob(dob), _address(address)
	{}
	
public:
	std::string getID() { return _id; }
	std::string getName() { return _name; }
	std::string getGPA() { return _gpa; }
	std::string getTelephone() { return _telephone; }
	std::string getEmail() { return _email; }
	std::string getDOB() { return _dob; }
	std::string getAddress() { return _address; }

public:
	static bool isValidDOB(const std::string &dob);
	static bool isValidID(const std::string &id);
	static bool isValidName(const std::string& name);
	static bool isValidGPA(const std::string& GPA);
	static bool isValidTelephone(const std::string &telephone);
	static bool isValidemail(const std::string& email);
};




