#include <iostream>
#include <string>
#include <vector>
#include <sstream>


class RandomGenerator {
public:
	RandomGenerator() {
		srand(time(NULL));
	}
	int nextInt(int ceiling) {
		return rand() % ceiling;
	}

	int nextInt(int left, int right) {
		return rand() % (right - left + 1) + left;
	}
	
	std::string nextID();
	std::string nextName();
	std::string nextGPA();
	std::string nextTelephone();
	std::string nextEmail();
	std::string nextDOB();
	std::string nextAddress();
};
