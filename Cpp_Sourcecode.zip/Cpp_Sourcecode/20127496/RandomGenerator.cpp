#include "RandomGenerator.h"
std::string RandomGenerator::nextID() {
	int buffer = nextInt(10, 99);
	std::stringstream builder;
	builder << "21274" << buffer;
	std::string result = builder.str();
	return result;
}

std::string RandomGenerator::nextName() {
	std::vector<std::string> firstName = { "Nguyen", "Ton", "Tran", "Hoang", "Phan" };
	std::vector<std::string> middleName = { "Thai", "Diem", "Thi", "Phung", "Ngoc" };
	std::vector<std::string> lastName = { "Hiep", "Quynh", "Quan", "Quang", "Khai" };
	int iFirstName = nextInt(firstName.size());
	int iMiddleName = nextInt(middleName.size());
	int iLastName = nextInt(lastName.size());
	std::string result = firstName[iFirstName] + " "
		+ middleName[iMiddleName] + " " + lastName[iLastName];
	return result;
}

std::string RandomGenerator::nextGPA() {
	// Why magic number ?
	// example: gpa=8.19 
	// 8 in range(0, 9)
	// 19 in range(0, 99)
	int first = nextInt(10);
	int second = nextInt(100);
	std::stringstream builder;
	builder << first << "." << second;
	std::string result = builder.str();
	return result;
}

std::string RandomGenerator::nextTelephone() {
	// why magic number?
	// example: tel=0-123-456-789
	// 123 in range(100, 999) ...
	int buffer[] = { nextInt(100,999), nextInt(100, 999), nextInt(100, 999) };
	std::stringstream builder;
	builder << "0" << buffer[0] << "-" << buffer[1] << "-" << buffer[2];
	std::string result = builder.str();
	return result;
}
std::string RandomGenerator::nextEmail() {
	std::vector<std::string> emailName = { "nthiep", "ilove", "mylove", "mybaby", "haizz" };
	int iName = nextInt(emailName.size());
	std::stringstream builder;
	builder << emailName[iName] << "@student.hcmus.edu.vn";
	std::string result = builder.str();
	return result;
}

std::string RandomGenerator::nextDOB() {
	int day = nextInt(1, 31); // Why 31? because day in range(1, 31) 
	int month = nextInt(12); // the same in line 73
	std::vector<std::string> year = { "2002", "2003", "1999", "1998", "2021" };
	int iYear = nextInt(year.size());
	std::stringstream builder;
	builder << day << "/" << month << "/" << year[iYear];
	std::string result = builder.str();
	return result;
}

std::string RandomGenerator::nextAddress() {
	const int NUMBERHOME = 300;
	int number = nextInt(NUMBERHOME);
	std::vector<std::string> streetName = { "Ngo Quyen", "My Phung",
		"Hoang An Ma", "Hoang Anh Gia Lai", "Nguyen Truong To" };
	int iStreet = nextInt(streetName.size());
	std::vector<std::string> wardName = { "Co Don", "Binh Hung Hoa",
		"Le Chieu Toan", "Nguyen Thai Hiep" };
	int iWard = nextInt(wardName.size());
	std::vector<std::string> districtName = { "Bin Tan", "Met Moi",
		"Dau Lung", "Moi Goi", "Te Bi" };
	int iDistrict = nextInt(districtName.size());
	std::vector<std::string> cityName = { "Ho Chi Minh", "Hue", "Ha Noi", "Da Nang" };
	int iCity = nextInt(cityName.size());
	std::stringstream builder;
	builder << number << " " << streetName[iStreet] << ", " << wardName[iWard] << " Wrad, "
		<< districtName[iDistrict] << " District, " << cityName[iCity] << " city.";
	std::string result = builder.str();
	return result;
}
