#include "DbSet.h"

std::tuple<bool, int, std::string, std::vector<std::shared_ptr<Student>>> DbSet::getAll() {
	std::tuple<bool, int, std::string, std::vector<std::shared_ptr<Student>>> result;
	std::vector<std::shared_ptr<Student>> target;
	std::fstream fin(_filename);
	if (!fin.is_open()) {
		result = make_tuple(false, 1, "Can not open file!", target);
		return result;
	}
	int line = 1;
	std::string buffer; // get one line in file 
	std::string id, name, gpa, telephone, email, dob, address;
	bool isRead;
	while (getline(fin, buffer)) {
		isRead = false;
		if (buffer == "") {
			continue;
		}
		if (buffer[0] == 'S') {
			int twodots = buffer.find(":");
			int dau_gach_ngang = buffer.find(" - ");
			id = buffer.substr(twodots + 2, dau_gach_ngang - twodots - 2);
			name = buffer.substr(dau_gach_ngang + 3, buffer.size() - dau_gach_ngang - 3);
			if (!Student::isValidName(name)) {
				result = make_tuple(false, 1, "Line " + std::to_string(line)
					+ ": Format Name Error!", target);
				return result;
			}
			if (!Student::isValidID(id)) {
				result = make_tuple(false, 1, "Line " + std::to_string(line)
					+ ": Format ID Error!", target);
				return result;
			}
			isRead = true;
		}
		if (buffer[4] == 'G') {
			int equal = buffer.find("=");
			int dau_phay = buffer.find(", ");
			int equal_thu_2 = buffer.find("=", dau_phay);
			gpa = buffer.substr(equal + 1, dau_phay - equal - 1);
			telephone = buffer.substr(equal_thu_2 + 1, buffer.size() - equal_thu_2 - 1);
			if (!Student::isValidGPA(gpa)) {
				result = make_tuple(false, 1, "Line " + std::to_string(line) +
					": Format GPA Error!", target);
				return result;
			}
			if (!Student::isValidTelephone(telephone)) {
				result = make_tuple(false, 1, "Line " + std::to_string(line) +
					": Format Telephone Error!", target);
				return result;
			}
			isRead = true;
		}
		if (buffer[4] == 'E' || buffer[4] == 'D' || buffer[4] == 'A') {
			int equal = buffer.find("=");
			std::string value = buffer.substr(equal + 1, buffer.size() - equal - 1);

			if (buffer[4] == 'E') {
				email = value;
				if (!Student::isValidemail(email)) {
					result = make_tuple(false, 1, "Line " + std::to_string(line)
						+ ": Format Email Error!", target);
					return result;
				}
			}
			if (buffer[4] == 'D') {
				dob = value;
				if (!Student::isValidDOB(dob)) {
					result = make_tuple(false, 1, "Line " + std::to_string(line)
						+ ": Format DOB Error!", target);
					return result;
				}
			}
			if (buffer[4] == 'A') {
				address = value;
				target.push_back(std::make_shared<Student>(
					Student(id, name, gpa, telephone, email, dob, address)));
			}
			isRead = true;
		}
		if (isRead == false) {
			result = make_tuple(false, 1, "Line " + std::to_string(line)
				+ ": Format Error!", target);
		}
		line++;
	}
	_students = target;
	result = make_tuple(true, 0, "", target);
	fin.close();
	return result;
}

std::pair<bool, std::string> DbSet::overWrite(const std::vector <std::shared_ptr<Student>>& Students) {
	std::pair<bool, std::string> result;
	result.first = true;
	result.second = "";
	std::ofstream fout(_filename, std::ios::app);
	if (!fout.is_open()) {
		result.first = false;
		result.second = "Can not open file to over write";
	}
	fout << std::endl;
	for (auto item : Students) {
		fout << "Student: " << item->getID() << " - " << item->getName() << std::endl <<
			"    GPA=" << item->getGPA() << ", Telephone=" << item->getTelephone()
			<< std::endl <<
			"    Email=" << item->getEmail() << std::endl <<
			"    DOB=" << item->getDOB() << std::endl <<
			"    Address=" << item->getAddress() << std::endl;
	}
	fout.close();
	return result;
}

std::vector<std::shared_ptr<Student>> DbSet::getRandomStudent() {
	std::vector<std::shared_ptr<Student>> result;
	RandomGenerator _rng;
	int n = _rng.nextInt(5, 10);
	std::string id, name, gpa, telephone, email, dob, address;
	for (int i = 0; i < n; i++) {
		id = _rng.nextID();
		name = _rng.nextName();
		gpa = _rng.nextGPA();
		telephone = _rng.nextTelephone();
		email = _rng.nextEmail();
		dob = _rng.nextDOB();
		address = _rng.nextAddress();
		result.push_back(std::make_shared<Student>(
			Student(id, name, gpa, telephone, email, dob, address)));
	}
	return result;
}

std::vector<std::shared_ptr<Student>> DbSet::concat(const std::vector<std::shared_ptr<Student>>& other) {
	std::vector<std::shared_ptr<Student>> result = other;
	for (auto item : _students) {
		result.push_back(item);
	}
	return result;
}
