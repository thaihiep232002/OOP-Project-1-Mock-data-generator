#include <string>
#include <sstream>
#include <vector>

class StudentToStringUIConverter {
public:
	std::string next(std::shared_ptr<Student> item) {
		std::stringstream builder;
		builder << item->getID() << " - " << item->getName() 
			<< ", GPA: " << item->getGPA();
		std::string result = builder.str();
		return result;
	}
};

