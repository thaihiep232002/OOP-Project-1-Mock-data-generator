FullName: Nguyễn Thái Hiệp
ID: 20127496

Lí do: Em code thêm C/C++ bởi vì sợ rằng mã nguồn Java kia điểm không cao

Điểm mong đợi: 10đ


